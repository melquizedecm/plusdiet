<?php

class Config {
    function conectar() {
        ///PARAMETROS PARA WEB

        $DBuser = 'root';
        $DBpass = '';
        $DBserver = 'localhost';
        $DBdatos = 'caros';

        ////////////NUEVO METODO DE CONEXION////////////////////

        $link = mysqli_connect($DBserver, $DBuser, $DBpass, $DBdatos);

        return $link;
    }

}
