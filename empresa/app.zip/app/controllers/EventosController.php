<?php
require_once "../models/Eventos.php";
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class EventosController extends Eventos {
            
    function index() {
        
        $tabla = parent::read();
        require_once("../view/eventos.php");
    }

//
//
//
//if (isset($_POST['tipo'])){
//    
//    $tipo=$_POST['tipo'];
//    $destino=$_POST['destino'];
//    $url_imagen='001.jpg';
//    $eventos = new Eventos($tipo, $destino, $url_imagen);
//    $result= $eventos->create();
//    
//    if($result){
//        $msg="Registro Agregado con exito";
//      //  header("location: ../views/index.php?msg=".$msg);
//    }
//    else{
//        $msg="Error al guardar";
//      //  header("location: ../views/index.php?msg=".$msg);
//    }
//    echo $msg;
//}

}

$eventos=new EventosController();
$eventos->index();