<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<table class = "table">
    <tr>
        <td><strong>SERVICIO</strong></td>
        <td><strong>PRECIO</strong></td>
    </tr><?php
    foreach ($tabla as $datos) {
            ?>
            <tr>
                <td><?php echo $datos['tipo']; ?></td>
                <td><?php echo $datos['destino']; ?> </td>
            </tr>
            <?php
        }
?>
</table>